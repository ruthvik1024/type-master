import React, { useState } from 'react';
import { useTyping, LessonLevel } from '../contexts/TypingContext';
import { lessons } from '../data/lessons';
import { ChevronDown } from 'lucide-react';

const LevelTab: React.FC<{
  level: LessonLevel;
  currentLevel: LessonLevel;
  onClick: () => void;
}> = ({ level, currentLevel, onClick }) => {
  const isActive = level === currentLevel;
  
  const capitalizedLevel = level.charAt(0).toUpperCase() + level.slice(1);
  
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 transition-colors duration-200 ${
        isActive
          ? 'bg-blue-500 text-white font-medium'
          : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
      } rounded-t-lg`}
    >
      {capitalizedLevel}
    </button>
  );
};

const LessonSelector: React.FC = () => {
  const { selectLesson, currentLessonId, currentLevel, changeLevel } = useTyping();
  const [isOpen, setIsOpen] = useState(false);
  
  const handleLevelChange = (level: LessonLevel) => {
    changeLevel(level);
  };
  
  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };
  
  const handleLessonSelect = (id: number) => {
    selectLesson(id);
    setIsOpen(false);
  };

  const currentLessonTitle = lessons[currentLevel].find(
    lesson => lesson.id === currentLessonId
  )?.title || '';

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="flex space-x-1 p-2 bg-gray-100 dark:bg-gray-900">
          <LevelTab
            level="beginner"
            currentLevel={currentLevel}
            onClick={() => handleLevelChange('beginner')}
          />
          <LevelTab
            level="intermediate"
            currentLevel={currentLevel}
            onClick={() => handleLevelChange('intermediate')}
          />
          <LevelTab
            level="advanced"
            currentLevel={currentLevel}
            onClick={() => handleLevelChange('advanced')}
          />
        </div>
        
        <div className="relative">
          <button
            onClick={toggleOpen}
            className="w-full p-4 text-left flex items-center justify-between bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <span className="font-medium text-gray-800 dark:text-white">
              {currentLessonTitle}
            </span>
            <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
          </button>
          
          {isOpen && (
            <div className="absolute z-10 w-full bg-white dark:bg-gray-800 shadow-lg rounded-b-lg max-h-60 overflow-y-auto">
              {lessons[currentLevel].map(lesson => (
                <button
                  key={lesson.id}
                  onClick={() => handleLessonSelect(lesson.id)}
                  className={`w-full p-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200 ${
                    lesson.id === currentLessonId ? 'bg-blue-50 dark:bg-blue-900/30 font-medium' : ''
                  }`}
                >
                  {lesson.title}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LessonSelector;