import React from 'react';
import { Keyboard, ArrowRight, BarChart3, CheckCircle2 } from 'lucide-react';
import { useTyping } from '../contexts/TypingContext';
import LessonSelector from './LessonSelector';

const StartScreen: React.FC = () => {
  const { startLesson, isLessonStarted } = useTyping();
  
  if (isLessonStarted) {
    return null;
  }

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="p-6 text-center">
          <div className="flex justify-center mb-4">
            <Keyboard className="h-16 w-16 text-blue-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
            Welcome to TypeMaster
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Improve your typing speed and accuracy with our interactive lessons
          </p>
          
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <ArrowRight className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-1">
                Start Typing
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Begin with simple lessons and advance to complex texts
              </p>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <BarChart3 className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-1">
                Track Progress
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Monitor your WPM, accuracy, and improvement over time
              </p>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <CheckCircle2 className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-1">
                Master Typing
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Build muscle memory and become a typing expert
              </p>
            </div>
          </div>
          
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            Choose a Lesson
          </h3>
        </div>
        
        <LessonSelector />
        
        <div className="p-6 text-center">
          <button
            onClick={startLesson}
            className="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-md transition-colors duration-200 flex items-center justify-center mx-auto"
          >
            Start Lesson
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default StartScreen;