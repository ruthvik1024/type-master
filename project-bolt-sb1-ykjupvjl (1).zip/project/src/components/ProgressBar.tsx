import React from 'react';
import { useTyping } from '../contexts/TypingContext';

const ProgressBar: React.FC = () => {
  const { progressPercentage } = useTyping();

  return (
    <div className="w-full max-w-3xl mx-auto px-4">
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-4 overflow-hidden">
        <div 
          className="h-2.5 rounded-full bg-gradient-to-r from-blue-500 to-green-500 transition-all duration-300 ease-out"
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default ProgressBar;