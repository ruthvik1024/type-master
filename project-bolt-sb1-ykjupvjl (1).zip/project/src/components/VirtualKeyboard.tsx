import React from 'react';
import { useTyping } from '../contexts/TypingContext';

const VirtualKeyboard: React.FC = () => {
  const { userInput, text } = useTyping();
  
  // Determine the currently expected key
  const expectedKey = text[userInput.length] || '';
  
  // Define the keyboard layout
  const keyboardRows = [
    ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'Backspace'],
    ['Tab', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\'],
    ['Caps', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', 'Enter'],
    ['Shift', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 'Shift'],
    ['Ctrl', 'Win', 'Alt', 'Space', 'Alt', 'Win', 'Menu', 'Ctrl']
  ];

  // Handle key styling
  const getKeyClass = (key: string) => {
    // Base styling for all keys
    let className = 'p-2 rounded-md flex items-center justify-center transition-all duration-150 ';
    
    // Special key sizes
    if (key === 'Space') {
      className += 'col-span-5 ';
    } else if (['Backspace', 'Tab', 'Caps', 'Enter', 'Shift'].includes(key)) {
      className += 'col-span-2 ';
    } else {
      className += 'aspect-square ';
    }
    
    // Compare with expected key (case insensitive for letters)
    let normalizedExpectedKey = expectedKey.toLowerCase();
    let normalizedKey = key.toLowerCase();
    
    // Handle special cases
    if (expectedKey === ' ' && key === 'Space') {
      normalizedExpectedKey = 'space';
      normalizedKey = 'space';
    }
    
    if (normalizedKey === normalizedExpectedKey) {
      className += 'bg-blue-500 text-white shadow-lg scale-110 z-10 ';
    } else {
      className += 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 ';
    }
    
    return className;
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-4 mt-4">
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        {keyboardRows.map((row, rowIndex) => (
          <div 
            key={rowIndex} 
            className="grid gap-1 mb-1"
            style={{ 
              gridTemplateColumns: `repeat(${rowIndex === 0 ? 14 : rowIndex === 1 ? 14 : rowIndex === 2 ? 13 : rowIndex === 3 ? 12 : 8}, minmax(0, 1fr))`
            }}
          >
            {row.map((key, keyIndex) => (
              <div key={keyIndex} className={getKeyClass(key)}>
                {key === 'Space' ? '⎵' : key}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default VirtualKeyboard;