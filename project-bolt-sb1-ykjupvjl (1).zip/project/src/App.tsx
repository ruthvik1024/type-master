import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { TypingProvider } from './contexts/TypingContext';
import TypingApp from './pages/TypingApp';

function App() {
  return (
    <ThemeProvider>
      <TypingProvider>
        <TypingApp />
      </TypingProvider>
    </ThemeProvider>
  );
}

export default App;