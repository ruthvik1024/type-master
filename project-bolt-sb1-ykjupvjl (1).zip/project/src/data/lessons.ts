export type Lesson = {
  id: number;
  title: string;
  text: string;
  level: 'beginner' | 'intermediate' | 'advanced';
};

export const lessons = {
  beginner: [
    {
      id: 1,
      title: 'Home Row',
      text: 'asdfjkl; asdfjkl; asdfjkl; asdfjkl; asdfjkl; asdfjkl; asdfjkl; asdfjkl;',
      level: 'beginner',
    },
    {
      id: 2,
      title: 'Top Row',
      text: 'qwertyuiop qwertyuiop qwertyuiop qwertyuiop qwertyuiop qwertyuiop',
      level: 'beginner',
    },
    {
      id: 3,
      title: 'Bottom Row',
      text: 'zxcvbnm zxcvbnm zxcvbnm zxcvbnm zxcvbnm zxcvbnm zxcvbnm zxcvbnm',
      level: 'beginner',
    },
    {
      id: 4,
      title: 'All Letters',
      text: 'the quick brown fox jumps over the lazy dog the quick brown fox jumps over the lazy dog',
      level: 'beginner',
    },
  ],
  intermediate: [
    {
      id: 5,
      title: 'Common Words',
      text: 'the and you that is in are be have it for not on with he as by at from your this was but they will some what about which when there use an each',
      level: 'intermediate',
    },
    {
      id: 6,
      title: 'Numbers',
      text: '1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890',
      level: 'intermediate',
    },
    {
      id: 7,
      title: 'Punctuation',
      text: 'Hello, world! How are you? That\'s great; I\'m doing well too. Do you have any questions? I\'m here to help!',
      level: 'intermediate',
    },
    {
      id: 8,
      title: 'Capitalization',
      text: 'The Sun rises in the East and sets in the West. Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, and Sunday are days of the week.',
      level: 'intermediate',
    },
  ],
  advanced: [
    {
      id: 9,
      title: 'Programming Syntax',
      text: 'function calculateSum(a, b) { return a + b; } const result = calculateSum(5, 10); console.log(`The sum is ${result}`);',
      level: 'advanced',
    },
    {
      id: 10,
      title: 'Complex Punctuation',
      text: '"To be, or not to be: that is the question: Whether \'tis nobler in the mind to suffer the slings and arrows of outrageous fortune..."',
      level: 'advanced',
    },
    {
      id: 11,
      title: 'Symbols and Special Characters',
      text: '@ # $ % ^ & * ( ) _ + - = [ ] { } \\ | ; : \' " , . < > / ? ~ ` ! These are common symbols used in typing.',
      level: 'advanced',
    },
    {
      id: 12,
      title: 'Speed Challenge',
      text: 'The five boxing wizards jump quickly. A quick movement of the enemy will jeopardize five gunboats. Pack my box with five dozen liquor jugs.',
      level: 'advanced',
    },
  ],
};