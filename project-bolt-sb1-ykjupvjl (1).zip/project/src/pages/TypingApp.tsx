import React from 'react';
import { useTyping } from '../contexts/TypingContext';
import Header from '../components/Header';
import StartScreen from '../components/StartScreen';
import TypingArea from '../components/TypingArea';
import ProgressBar from '../components/ProgressBar';
import StatsPanel from '../components/StatsPanel';
import VirtualKeyboard from '../components/VirtualKeyboard';
import LessonControls from '../components/LessonControls';

const TypingApp: React.FC = () => {
  const { isLessonStarted } = useTyping();

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
      <Header />
      
      <main className="container mx-auto px-4 pb-16">
        {!isLessonStarted ? (
          <StartScreen />
        ) : (
          <>
            <ProgressBar />
            <TypingArea />
            <StatsPanel />
            <LessonControls />
            <VirtualKeyboard />
          </>
        )}
      </main>
    </div>
  );
};

export default TypingApp;