import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { lessons } from '../data/lessons';

export type LessonLevel = 'beginner' | 'intermediate' | 'advanced';

type TypingContextType = {
  text: string;
  userInput: string;
  isComplete: boolean;
  typedCharacters: number;
  correctCharacters: number;
  errors: number;
  accuracy: number;
  wpm: number;
  cpm: number;
  startTime: number | null;
  elapsedTime: number;
  currentLessonId: number;
  currentLevel: LessonLevel;
  isLessonStarted: boolean;
  progressPercentage: number;
  
  setUserInput: (input: string) => void;
  startLesson: () => void;
  restartLesson: () => void;
  nextLesson: () => void;
  selectLesson: (id: number) => void;
  changeLevel: (level: LessonLevel) => void;
};

const TypingContext = createContext<TypingContextType | undefined>(undefined);

export const TypingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [text, setText] = useState('');
  const [userInput, setUserInput] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [typedCharacters, setTypedCharacters] = useState(0);
  const [correctCharacters, setCorrectCharacters] = useState(0);
  const [errors, setErrors] = useState(0);
  const [accuracy, setAccuracy] = useState(0);
  const [wpm, setWpm] = useState(0);
  const [cpm, setCpm] = useState(0);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [currentLessonId, setCurrentLessonId] = useState(0);
  const [currentLevel, setCurrentLevel] = useState<LessonLevel>('beginner');
  const [isLessonStarted, setIsLessonStarted] = useState(false);
  const [progressPercentage, setProgressPercentage] = useState(0);

  // Initialize lesson text
  useEffect(() => {
    const currentLesson = lessons[currentLevel].find(lesson => lesson.id === currentLessonId);
    if (currentLesson) {
      setText(currentLesson.text);
    }
  }, [currentLessonId, currentLevel]);

  // Handle typing metrics calculation
  useEffect(() => {
    if (!isLessonStarted || !startTime) return;

    const currentTime = Date.now();
    const timeElapsed = (currentTime - startTime) / 1000; // in seconds
    setElapsedTime(timeElapsed);

    if (timeElapsed > 0) {
      // Calculate WPM (standard: 5 characters = 1 word)
      const wordsTyped = correctCharacters / 5;
      const calculatedWpm = Math.round((wordsTyped / timeElapsed) * 60);
      setWpm(calculatedWpm);

      // Calculate CPM
      const calculatedCpm = Math.round((correctCharacters / timeElapsed) * 60);
      setCpm(calculatedCpm);
    }

    // Calculate accuracy
    if (typedCharacters > 0) {
      const calculatedAccuracy = Math.round((correctCharacters / typedCharacters) * 100);
      setAccuracy(calculatedAccuracy);
    }

    // Calculate progress
    const progress = Math.min(100, Math.round((userInput.length / text.length) * 100));
    setProgressPercentage(progress);

    // Check if lesson is complete
    if (userInput.length === text.length) {
      setIsComplete(true);
    }
  }, [userInput, correctCharacters, typedCharacters, startTime, isLessonStarted, text]);

  // Handle user input and character checking
  const handleUserInput = useCallback((input: string) => {
    if (isComplete) return;
    
    // Start the timer on first input
    if (!startTime && input.length > 0) {
      setStartTime(Date.now());
      setIsLessonStarted(true);
    }

    // Only allow as many characters as in the lesson text
    if (input.length > text.length) {
      return;
    }

    setUserInput(input);
    setTypedCharacters(input.length);

    // Count correct characters and errors
    let correctCount = 0;
    let errorCount = 0;
    
    for (let i = 0; i < input.length; i++) {
      if (input[i] === text[i]) {
        correctCount++;
      } else {
        errorCount++;
      }
    }
    
    setCorrectCharacters(correctCount);
    setErrors(errorCount);
  }, [isComplete, startTime, text]);

  // Control functions
  const startLesson = useCallback(() => {
    setUserInput('');
    setIsComplete(false);
    setTypedCharacters(0);
    setCorrectCharacters(0);
    setErrors(0);
    setAccuracy(0);
    setWpm(0);
    setCpm(0);
    setStartTime(null);
    setElapsedTime(0);
    setIsLessonStarted(false);
    setProgressPercentage(0);
  }, []);

  const restartLesson = useCallback(() => {
    startLesson();
  }, [startLesson]);

  const nextLesson = useCallback(() => {
    const currentLevelLessons = lessons[currentLevel];
    const nextLessonIndex = currentLevelLessons.findIndex(lesson => lesson.id === currentLessonId) + 1;
    
    if (nextLessonIndex < currentLevelLessons.length) {
      setCurrentLessonId(currentLevelLessons[nextLessonIndex].id);
    } else if (currentLevel === 'beginner') {
      setCurrentLevel('intermediate');
      setCurrentLessonId(lessons.intermediate[0].id);
    } else if (currentLevel === 'intermediate') {
      setCurrentLevel('advanced');
      setCurrentLessonId(lessons.advanced[0].id);
    }
    
    startLesson();
  }, [currentLessonId, currentLevel, startLesson]);

  const selectLesson = useCallback((id: number) => {
    setCurrentLessonId(id);
    startLesson();
  }, [startLesson]);

  const changeLevel = useCallback((level: LessonLevel) => {
    setCurrentLevel(level);
    setCurrentLessonId(lessons[level][0].id);
    startLesson();
  }, [startLesson]);

  return (
    <TypingContext.Provider
      value={{
        text,
        userInput,
        isComplete,
        typedCharacters,
        correctCharacters,
        errors,
        accuracy,
        wpm,
        cpm,
        startTime,
        elapsedTime,
        currentLessonId,
        currentLevel,
        isLessonStarted,
        progressPercentage,
        setUserInput: handleUserInput,
        startLesson,
        restartLesson,
        nextLesson,
        selectLesson,
        changeLevel,
      }}
    >
      {children}
    </TypingContext.Provider>
  );
};

export const useTyping = (): TypingContextType => {
  const context = useContext(TypingContext);
  if (context === undefined) {
    throw new Error('useTyping must be used within a TypingProvider');
  }
  return context;
};