import React from 'react';
import { useTyping } from '../contexts/TypingContext';
import { RefreshCw, ChevronRight } from 'lucide-react';

const LessonControls: React.FC = () => {
  const {
    restartLesson,
    nextLesson,
    isComplete,
    isLessonStarted
  } = useTyping();

  if (!isLessonStarted && !isComplete) {
    return null;
  }

  return (
    <div className="w-full max-w-3xl mx-auto p-4 flex justify-center space-x-4">
      <button
        onClick={restartLesson}
        className="flex items-center px-6 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-md transition-colors duration-200"
      >
        <RefreshCw className="w-4 h-4 mr-2" />
        Restart
      </button>
      
      {isComplete && (
        <button
          onClick={nextLesson}
          className="flex items-center px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-md transition-colors duration-200"
        >
          Next Lesson
          <ChevronRight className="w-4 h-4 ml-2" />
        </button>
      )}
    </div>
  );
};

export default LessonControls;