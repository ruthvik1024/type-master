import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Keyboard, Sun, Moon } from 'lucide-react';

const Header: React.FC = () => {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <header className="w-full bg-white dark:bg-gray-800 shadow-md py-4 px-6 mb-8 transition-all duration-300">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <Keyboard className="h-7 w-7 text-blue-500 mr-3" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Type<span className="text-blue-500">Master</span>
          </h1>
        </div>
        
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
          aria-label={isDarkMode ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {isDarkMode ? (
            <Sun className="h-5 w-5 text-amber-400" />
          ) : (
            <Moon className="h-5 w-5 text-blue-700" />
          )}
        </button>
      </div>
    </header>
  );
};

export default Header;