import React, { useEffect, useRef } from 'react';
import { useTyping } from '../contexts/TypingContext';

const TypingArea: React.FC = () => {
  const {
    text,
    userInput,
    setUserInput,
    isComplete,
    isLessonStarted,
  } = useTyping();
  
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Focus input on initial render
    if (inputRef.current && !isComplete) {
      inputRef.current.focus();
    }
  }, [isComplete]);

  const renderCharacters = () => {
    return text.split('').map((char, index) => {
      let className = 'text-gray-600 dark:text-gray-400';
      
      if (index < userInput.length) {
        // Character has been typed
        if (userInput[index] === char) {
          className = 'text-green-500 dark:text-green-400'; // Correct
        } else {
          className = 'text-red-500 dark:text-red-400 bg-red-100 dark:bg-red-900/30'; // Incorrect
        }
      } else if (index === userInput.length) {
        className = 'text-blue-500 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30'; // Current position
      }
      
      // Handle spaces to make them visible
      if (char === ' ') {
        return (
          <span key={index} className={`${className} relative`}>
            <span className="invisible">_</span>
            <span className="absolute inset-0 w-full">·</span>
          </span>
        );
      }
      
      return (
        <span key={index} className={className}>
          {char}
        </span>
      );
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserInput(e.target.value);
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <div
        className="text-2xl mb-6 font-mono leading-relaxed tracking-wide bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md overflow-hidden transition-all duration-300"
        onClick={() => inputRef.current?.focus()}
      >
        {renderCharacters()}
      </div>
      
      <input
        ref={inputRef}
        type="text"
        value={userInput}
        onChange={handleInputChange}
        disabled={isComplete}
        className="opacity-0 absolute left-0 w-1"
        aria-hidden="true"
      />
      
      {!isLessonStarted && !isComplete && (
        <div className="text-center text-gray-600 dark:text-gray-400 mt-4">
          Begin typing to start the lesson
        </div>
      )}
      
      {isComplete && (
        <div className="text-center text-green-500 dark:text-green-400 mt-4 text-xl font-semibold">
          Lesson complete! 🎉
        </div>
      )}
    </div>
  );
};

export default TypingArea;