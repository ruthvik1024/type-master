import React from 'react';
import { useTyping } from '../contexts/TypingContext';
import { Activity, BarChart2, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const StatsPanel: React.FC = () => {
  const {
    wpm,
    cpm,
    accuracy,
    elapsedTime,
    correctCharacters,
    errors,
    isLessonStarted,
  } = useTyping();

  // Format time as MM:SS
  const formatTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Don't show stats until the lesson has started
  if (!isLessonStarted) {
    return null;
  }

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex flex-col items-center justify-center transition-all duration-300 hover:shadow-lg">
          <div className="flex items-center justify-center mb-2">
            <Activity className="w-5 h-5 text-blue-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-400 text-sm font-medium">WPM</span>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white">{wpm}</span>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex flex-col items-center justify-center transition-all duration-300 hover:shadow-lg">
          <div className="flex items-center justify-center mb-2">
            <BarChart2 className="w-5 h-5 text-purple-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-400 text-sm font-medium">CPM</span>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white">{cpm}</span>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex flex-col items-center justify-center transition-all duration-300 hover:shadow-lg">
          <div className="flex items-center justify-center mb-2">
            <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-400 text-sm font-medium">Accuracy</span>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white">{accuracy}%</span>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex flex-col items-center justify-center transition-all duration-300 hover:shadow-lg">
          <div className="flex items-center justify-center mb-2">
            <Clock className="w-5 h-5 text-amber-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-400 text-sm font-medium">Time</span>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white">{formatTime(elapsedTime)}</span>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex flex-col items-center justify-center transition-all duration-300 hover:shadow-lg">
          <div className="flex items-center justify-center mb-2">
            <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
            <span className="text-gray-600 dark:text-gray-400 text-sm font-medium">Errors</span>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white">{errors}</span>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;