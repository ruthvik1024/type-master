import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/layout/Layout';
import Hero from './components/sections/Hero';
import Features from './components/sections/Features';
import Testimonials from './components/sections/Testimonials';
import Newsletter from './components/sections/Newsletter';

function App() {
  return (
    <ThemeProvider>
      <Layout>
        <Hero />
        <Features />
        <Testimonials />
        <Newsletter />
      </Layout>
    </ThemeProvider>
  );
}

export default App;