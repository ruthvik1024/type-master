import React from 'react';
import { useTyping } from '../contexts/TypingContext';

const ProgressBar: React.FC = () => {
  const { currentText, typedText } = useTyping();
  const progress = (typedText.length / currentText.length) * 100;

  return (
    <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
      <div 
        className="h-full bg-blue-600 transition-all duration-200"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};

export default ProgressBar;