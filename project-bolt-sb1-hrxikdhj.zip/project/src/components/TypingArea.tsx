import React, { useEffect, useRef } from 'react';
import { useTyping } from '../contexts/TypingContext';

const TypingArea: React.FC = () => {
  const { 
    currentText, 
    typedText, 
    setTypedText,
    isCompleted
  } = useTyping();
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    if (!isCompleted && newValue.length <= currentText.length) {
      setTypedText(newValue);
    }
  };

  const renderText = () => {
    return currentText.split('').map((char, index) => {
      let className = '';
      
      if (index < typedText.length) {
        className = typedText[index] === char ? 'text-green-500' : 'text-red-500';
      }
      
      return (
        <span key={index} className={className}>
          {char}
        </span>
      );
    });
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
      <div className="mb-4 font-mono text-lg leading-relaxed">
        {renderText()}
      </div>
      <textarea
        ref={textareaRef}
        value={typedText}
        onChange={handleInput}
        className="w-full h-24 p-4 font-mono text-lg bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Start typing..."
        disabled={isCompleted}
      />
    </div>
  );
};

export default TypingArea;