import React from 'react';
import { Zap, Shield, BarChart, Users, Clock, Smartphone } from 'lucide-react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700 group">
      <div className="mb-4 inline-flex items-center justify-center w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </div>
  );
};

const Features: React.FC = () => {
  const features = [
    {
      icon: <Zap size={24} />,
      title: 'Lightning Fast',
      description: 'Our platform is optimized for speed to ensure your team can work efficiently without delays.'
    },
    {
      icon: <Shield size={24} />,
      title: 'Enterprise Security',
      description: 'Advanced encryption and security protocols to keep your sensitive data protected at all times.'
    },
    {
      icon: <BarChart size={24} />,
      title: 'Detailed Analytics',
      description: 'Comprehensive reports and insights to help you make data-driven decisions for your business.'
    },
    {
      icon: <Users size={24} />,
      title: 'Team Collaboration',
      description: 'Seamless tools for your team to work together effectively regardless of location.'
    },
    {
      icon: <Clock size={24} />,
      title: 'Automation',
      description: 'Save valuable time by automating repetitive tasks and focusing on what matters.'
    },
    {
      icon: <Smartphone size={24} />,
      title: 'Mobile Optimized',
      description: 'Access your dashboard and tools from any device with our responsive design.'
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50 dark:bg-gray-900/50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Powerful Features for Modern Businesses
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Everything you need to streamline your operations and accelerate growth.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="#" 
            className="inline-flex items-center px-6 py-3 border border-blue-600 text-blue-600 dark:text-blue-400 dark:border-blue-400 font-medium rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
          >
            Explore All Features
          </a>
        </div>
      </div>
    </section>
  );
};

export default Features;