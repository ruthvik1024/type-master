import React, { useState } from 'react';
import { Send, Check, AlertCircle } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email
    if (!validateEmail(email)) {
      setStatus('error');
      setErrorMessage('Please enter a valid email address');
      return;
    }
    
    // Simulate API call
    setStatus('loading');
    
    setTimeout(() => {
      setStatus('success');
      setEmail('');
      
      // Reset success state after 3 seconds
      setTimeout(() => {
        setStatus('idle');
      }, 3000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Stay Updated with Our Newsletter
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Get the latest updates, news, and special offers directly to your inbox.
          </p>
          
          <form onSubmit={handleSubmit} className="relative max-w-lg mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-grow">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (status === 'error') setStatus('idle');
                  }}
                  placeholder="Enter your email address"
                  className={`w-full px-4 py-3 rounded-lg border ${
                    status === 'error'
                      ? 'border-red-500 dark:border-red-400 focus:ring-red-200 dark:focus:ring-red-900'
                      : 'border-gray-300 dark:border-gray-600 focus:ring-blue-200 dark:focus:ring-blue-900'
                  } focus:border-blue-500 dark:focus:border-blue-400 focus:ring-4 focus:outline-none dark:bg-gray-700 dark:text-white transition-colors`}
                  disabled={status === 'loading' || status === 'success'}
                />
                {status === 'error' && (
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-red-500 dark:text-red-400">
                    <AlertCircle size={18} />
                  </div>
                )}
              </div>
              <button
                type="submit"
                disabled={status === 'loading' || status === 'success'}
                className={`px-6 py-3 rounded-lg font-medium text-white transition-all shadow-md flex items-center justify-center ${
                  status === 'success'
                    ? 'bg-green-600 hover:bg-green-700'
                    : status === 'loading'
                    ? 'bg-blue-400 dark:bg-blue-500 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {status === 'loading' ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : status === 'success' ? (
                  <span className="flex items-center">
                    <Check size={18} className="mr-2" />
                    Subscribed!
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Send size={18} className="mr-2" />
                    Subscribe
                  </span>
                )}
              </button>
            </div>
            {status === 'error' && (
              <p className="mt-2 text-sm text-red-500 dark:text-red-400">{errorMessage}</p>
            )}
            <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;