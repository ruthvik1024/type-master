import React, { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simple parallax effect on scroll
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollPosition = window.scrollY;
        const translateY = scrollPosition * 0.3;
        heroRef.current.style.transform = `translateY(${translateY}px)`;
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative overflow-hidden">
      {/* Background graphics */}
      <div className="absolute inset-0 opacity-70 dark:opacity-30 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-300 dark:bg-purple-900 rounded-full filter blur-3xl"></div>
        <div className="absolute top-60 -left-20 w-60 h-60 bg-blue-300 dark:bg-blue-900 rounded-full filter blur-3xl"></div>
        <div className="absolute -bottom-40 right-20 w-60 h-60 bg-teal-300 dark:bg-teal-900 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 md:py-28 lg:py-32">
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="mb-6 inline-block">
            <span className="inline-block px-4 py-2 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-sm font-medium">
              Introducing Horizon 2.0
            </span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            <span className="block">Elevate Your Business with</span>
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
              Cutting-Edge Solutions
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-10 max-w-3xl mx-auto">
            Transform your company's potential with our innovative platform designed to streamline operations, boost productivity, and drive growth.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a 
              href="#" 
              className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group"
            >
              Get Started
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
            </a>
            <a 
              href="#" 
              className="px-8 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 font-medium rounded-lg transition-all shadow hover:shadow-md"
            >
              Learn More
            </a>
          </div>
        </div>
        
        <div ref={heroRef} className="mt-16 max-w-4xl mx-auto rounded-xl shadow-2xl overflow-hidden">
          <img 
            src="https://images.pexels.com/photos/8347499/pexels-photo-8347499.jpeg" 
            alt="Dashboard overview" 
            className="w-full h-auto"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;