import React from 'react';
import { useTyping } from '../contexts/TypingContext';

const StatsPanel: React.FC = () => {
  const { accuracy, wpm, mistakes } = useTyping();

  return (
    <div className="flex justify-center gap-8 mb-8">
      <div className="text-center">
        <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
          {wpm}
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">WPM</div>
      </div>
      
      <div className="text-center">
        <div className="text-3xl font-bold text-green-600 dark:text-green-400">
          {accuracy}%
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">Accuracy</div>
      </div>
      
      <div className="text-center">
        <div className="text-3xl font-bold text-red-600 dark:text-red-400">
          {mistakes}
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">Mistakes</div>
      </div>
    </div>
  );
};

export default StatsPanel;