import React from 'react';
import { useTyping } from '../contexts/TypingContext';
import { RotateCcw, ArrowRight } from 'lucide-react';

const LessonControls: React.FC = () => {
  const { isCompleted, nextLesson, resetLesson } = useTyping();

  return (
    <div className="flex justify-center gap-4 mt-6">
      <button
        onClick={resetLesson}
        className="px-6 py-2 flex items-center gap-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
      >
        <RotateCcw size={18} />
        Restart
      </button>
      
      {isCompleted && (
        <button
          onClick={nextLesson}
          className="px-6 py-2 flex items-center gap-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Next Lesson
          <ArrowRight size={18} />
        </button>
      )}
    </div>
  );
};

export default LessonControls;