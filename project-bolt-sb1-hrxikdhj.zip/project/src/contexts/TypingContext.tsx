import React, { createContext, useContext, useState, useEffect } from 'react';
import { lessons } from '../data/lessons';

interface TypingContextType {
  currentLesson: number;
  currentText: string;
  typedText: string;
  accuracy: number;
  wpm: number;
  isCompleted: boolean;
  mistakes: number;
  startTime: number | null;
  setTypedText: (text: string) => void;
  nextLesson: () => void;
  resetLesson: () => void;
  setCurrentLesson: (lessonIndex: number) => void;
}

const TypingContext = createContext<TypingContextType | undefined>(undefined);

export const TypingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLesson, setCurrentLesson] = useState(0);
  const [typedText, setTypedText] = useState('');
  const [startTime, setStartTime] = useState<number | null>(null);
  const [mistakes, setMistakes] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [wpm, setWPM] = useState(0);
  const [accuracy, setAccuracy] = useState(100);

  const currentText = lessons[currentLesson].text;

  useEffect(() => {
    if (typedText.length === 1 && !startTime) {
      setStartTime(Date.now());
    }

    if (typedText.length > 0) {
      // Calculate accuracy
      let mistakeCount = 0;
      for (let i = 0; i < typedText.length; i++) {
        if (typedText[i] !== currentText[i]) {
          mistakeCount++;
        }
      }
      setMistakes(mistakeCount);
      const accuracyValue = ((typedText.length - mistakeCount) / typedText.length) * 100;
      setAccuracy(Math.round(accuracyValue));

      // Calculate WPM
      if (startTime) {
        const timeElapsed = (Date.now() - startTime) / 1000 / 60; // in minutes
        const wordsTyped = typedText.length / 5; // assume average word length of 5 characters
        const currentWPM = Math.round(wordsTyped / timeElapsed);
        setWPM(currentWPM);
      }
    } else {
      setMistakes(0);
      setAccuracy(100);
      setWPM(0);
    }

    // Check if lesson is completed
    if (typedText === currentText) {
      setIsCompleted(true);
    }
  }, [typedText, currentText, startTime]);

  const nextLesson = () => {
    if (currentLesson < lessons.length - 1) {
      setCurrentLesson(currentLesson + 1);
      resetLesson();
    }
  };

  const resetLesson = () => {
    setTypedText('');
    setStartTime(null);
    setMistakes(0);
    setIsCompleted(false);
    setWPM(0);
    setAccuracy(100);
  };

  const value = {
    currentLesson,
    currentText,
    typedText,
    accuracy,
    wpm,
    isCompleted,
    mistakes,
    startTime,
    setTypedText,
    nextLesson,
    resetLesson,
    setCurrentLesson
  };

  return (
    <TypingContext.Provider value={value}>
      {children}
    </TypingContext.Provider>
  );
};

export const useTyping = () => {
  const context = useContext(TypingContext);
  if (context === undefined) {
    throw new Error('useTyping must be used within a TypingProvider');
  }
  return context;
};